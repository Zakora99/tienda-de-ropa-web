<?php
require_once "../model/carrito.php";
$model = new Carrito();

echo $model->getFrecuencias();

?>
