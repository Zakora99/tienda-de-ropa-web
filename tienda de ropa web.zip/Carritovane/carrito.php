<?php
require_once "model/carrito.php";
$model = new Carrito();
if (!isset($_SESSION['ID']))
    $res = $model->getCar(0);
else
    $res = $model->getCar($_SESSION['ID']);

$total = 0;
$count = 0;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Carrito</title>
    <link rel="shortcut icon" href="resources/img/logo.jpg" type="image/x-icon">
    <link rel="stylesheet" href="resources/libs/bootstrap_5/css/bootstrap.min.css">
    <link rel="stylesheet" href="resources/libs/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="resources/css/general.css">
    <link rel="stylesheet" href="resources/css/carrito.css">
</head>

<body>
    <header>
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">

                <a class="navbar-brand" href="index.php">
                    <img src="resources/img/logo.jpg" height="50px" alt="">
                    &nbsp;
                    Vane Shoop
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://facebook.com">
                                <i class="fab fa-facebook-square" aria-hidden="true" style="font-size: 15px; color: blue;"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" aria-disabled="true">55 6447 7055</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="graficas.php" aria-disabled="true">Metricas</a>
                        </li>
                    </ul>
                    <form class="d-flex d-5" style="position: relative;" role="search">
                        <a href="<?php if (!isset($_SESSION['ID'])) {
                                        echo "login.php";
                                    } else {
                                        echo "controller/close.php";
                                    } ?>">
                            <?php if (!isset($_SESSION['ID'])) {
                                echo "Iniciar sesión";
                            } else {
                                echo $_SESSION['nameUser'] . " - Cerrar Sesion";
                            } ?>
                        </a>
                        <a href="carrito.php"><img src="resources/img/cart.png" alt=""></a>
                        <span id="numberCar" class="circle">
                            2
                        </span>
                        &nbsp;
                    </form>
                </div>
            </div>
        </nav>
    </header>

    <center>
        <h1>Carrito de compra</h1>
        <hr style="width: 80%; margin: auto;">
    </center>

    <div class="container mt-3">
        <div class="row mb-5">
            <div class="cont-btn-return">
                <a href="index.php" class="btn btn-danger btn-sm">
                    <i class="fa fa-times-circle" aria-hidden="true"></i>
                </a>
            </div>
        </div>
        <div class="row">
            <table class="table table-hover table-bordered table-responsive">
                <thead class="table-primary">
                    <tr class="text-center">
                        <th>Codigo</th>
                        <th>Prenda</th>
                        <th>Cantidad</th>
                        <th>Importe</th>
                        <th>Controles</th>
                    </tr>
                </thead>
                <tbody>
                    <?php while ($item = $res->fetch_assoc()) { 
                        $count++;
                        $total += $item['price'];
                        ?>
                        <tr class="text-center">
                            <td><?php echo $item['fk_producto']; ?></td>
                            <td><?php echo $item['nombre_prenda']; ?></td>
                            <td><?php echo $item['cantida']; ?></td>
                            <td><?php echo $item['price']; ?></td>
                            <td>
                                <button class="btn btn-danger btn-sm" onclick="deteleteCar(<?php echo $item['id_carrito']; ?>)">
                                    <i class="fa fa-times" aria-hidden="true"></i>
                                </button>
                            </td>
                        </tr>
                    <?php } ?>
                    <tr class="table-primary text-center">
                        <td colspan="2"></td>
                        <td>TOTAL:</td>
                        <td>$<?php echo number_format($total,2); ?> MNX.</td>
                        <td>
                            <?php if($count > 0){ ?>
                            <button class="btn btn-success" onclick="pagar(<?php echo $_SESSION['ID']; ?>, <?php echo $total; ?>)">
                                Pagar
                                &nbsp;
                                <i class="fas fa-money-check-alt"></i>
                            </button>
                            <?php } ?>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
    </div>

    <script src="resources/libs/jquery.js"></script>
    <script src="resources/libs/sweetalert.js"></script>
    <script src="resources/libs/bootstrap_5/js/bootstrap.min.js"></script>
    <script src="resources/libs/fontawesome/js/all.min.js"></script>
    <script>
        var us = "<?php if (!isset($_SESSION['ID'])) echo "0";
                    else echo $_SESSION['ID']; ?>"
    </script>
    <script src="resources/js/carrito.js"></script>
</body>

</html>