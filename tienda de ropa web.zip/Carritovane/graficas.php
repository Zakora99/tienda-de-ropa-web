<?php
require_once "model/carrito.php";
$model = new Carrito();
if (!isset($_SESSION['ID']))
    $res = $model->getCar(0);
else
    $res = $model->getCar($_SESSION['ID']);

$total = 0;
$count = 0;

?>

<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    <title>Carrito</title>
    <link rel="shortcut icon" href="resources/img/logo.jpg" type="image/x-icon">
    <link rel="stylesheet" href="resources/libs/bootstrap_5/css/bootstrap.min.css">
    <link rel="stylesheet" href="resources/libs/fontawesome/css/all.min.css">
    <link rel="stylesheet" href="resources/css/general.css">
    <link rel="stylesheet" href="resources/css/carrito.css">
</head>
<style>
    canvas {
        border: 1px dotted red;
        color: #fff;
        overflow: hidden;
    }

    .chart-container {
        display: flex;
        position: relative;
        margin: auto;
        height: auto;
        width: 90%;
        height: 80vh;
        text-align: center;
        background-color: #fff;
    }

    .chart-container_2 {
        display: block;
        position: relative;
        margin: auto;
        height: auto;
        width: 40vw;
        text-align: center;
        background-color: #fff;
    }
</style>

<body>
    <header>
        <nav class="navbar navbar-expand-lg bg-body-tertiary">
            <div class="container-fluid">

                <a class="navbar-brand" href="index.php">
                    <img src="resources/img/logo.jpg" height="50px" alt="">
                    &nbsp;
                    Vane Shoop
                </a>
                <button class="navbar-toggler" type="button" data-bs-toggle="collapse" data-bs-target="#navbarSupportedContent" aria-controls="navbarSupportedContent" aria-expanded="false" aria-label="Toggle navigation">
                    <span class="navbar-toggler-icon"></span>
                </button>
                <div class="collapse navbar-collapse" id="navbarSupportedContent">
                    <ul class="navbar-nav me-auto mb-2 mb-lg-0">
                        <li class="nav-item">
                            <a class="nav-link active" aria-current="page" href="index.php">Home</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="https://facebook.com">
                                <i class="fab fa-facebook-square" aria-hidden="true" style="font-size: 15px; color: blue;"></i>
                            </a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link disabled" aria-disabled="true">55 6447 7055</a>
                        </li>
                        <li class="nav-item">
                            <a class="nav-link" href="graficas.php" aria-disabled="true">Metricas</a>
                        </li>
                    </ul>
                    <form class="d-flex d-5" style="position: relative;" role="search">
                        <a href="<?php if (!isset($_SESSION['ID'])) {
                                        echo "login.php";
                                    } else {
                                        echo "controller/close.php";
                                    } ?>">
                            <?php if (!isset($_SESSION['ID'])) {
                                echo "Iniciar sesión";
                            } else {
                                echo $_SESSION['nameUser'] . " - Cerrar Sesion";
                            } ?>
                        </a>
                        <a href="carrito.php"><img src="resources/img/cart.png" alt=""></a>
                        <span id="numberCar" class="circle">
                            2
                        </span>
                        &nbsp;
                    </form>
                </div>
            </div>
        </nav>
    </header>



    <center>
        <br>
        <h1>Stock Disponible</h1>

        <hr>
        <br>
    </center>
    <div class="chart-container_2">
        <canvas id="myChart"></canvas>
    </div>

    <br>
    <center>
        <br>
        <h1>Productos mas Vendidos</h1>

        <hr>
        <br>
    </center>

    <div class="chart-container mb-5">
        <canvas id="myChart_2"></canvas>
        <canvas id="myChart_3"></canvas>
    </div>

    <script src="resources/libs/jquery.js"></script>
    <script src="resources/libs/bootstrap_5/js/bootstrap.min.js"></script>
    <script src="resources/libs/fontawesome/js/all.min.js"></script>
    <script src="resources/libs/chart.js"></script>
    <script>
        var labels = [];
        let datas = [];

        var labels_2 = [];
        let datas_2 = [];

        $(function() {
            const ctx = document.getElementById('myChart');
            const ctx_2 = document.getElementById('myChart_2');
            const ctx_3 = document.getElementById('myChart_3');
            $.ajax({
                url: "controller/getGraphics.php",
                type: 'post',
                data: {},
                success: function(response) {

                    aux = JSON.parse(response);
                    $.each(aux, function(key, item) {
                        labels.push(item.label);
                        datas.push(item.cantidad)
                    });

                    new Chart(ctx, {
                        type: 'polarArea',
                        data: {
                            label: "Frecuencia de productos",
                            labels: labels,
                            datasets: [{
                                label: 'Promedio de Venta',
                                data: datas,
                                borderWidth: 2,
                            }]
                        },
                        autoPadding: true,
                        hoverOffset: 2
                    });
                    new Chart(ctx_3, {
                        type: 'bar',
                        data: {
                            label: "Frecuencia de productos",
                            labels: labels,
                            datasets: [{
                                label: '# Frecuencia',
                                data: datas,
                                borderWidth: 2,
                            }]
                        },
                        autoPadding: true,
                        hoverOffset: 2
                    });
                }
            });

            $.ajax({
                url: "controller/getStock.php",
                type: 'post',
                data: {},
                success: function(response) {
                    console.log(response);
                    aux = JSON.parse(response);
                    $.each(aux, function(key, item) {
                        labels_2.push(item.label);
                        datas_2.push(item.cantidad)
                    });

                    new Chart(ctx_2, {
                        type: 'doughnut',
                        label: "Cantidad de Stock",
                        data: {
                            labels: labels_2,
                            datasets: [{
                                label: '# Productos',
                                data: datas_2,
                                borderWidth: 2,
                            }]
                        },
                        autoPadding: true,
                        hoverOffset: 2
                    });
                }
            });

            window.addEventListener('beforeprint', () => {
                ctx.resize(600, 600);
            });
        })
    </script>

    <script>
        var us = "<?php if (!isset($_SESSION['ID'])) echo "0";
                    else echo $_SESSION['ID']; ?>"
    </script>
    <script src="resources/js/app.js"></script>