<?php
require_once "model/carrito.php";
require_once "resources/libs/fpdf/fpdf.php";

$model = new Carrito();
if (isset($_SESSION['ID'])) {
    $car = $model->getCar($_SESSION['ID']);
    $total = $model->getLastVentaP();
    $model->cleanCar($_SESSION['ID']);
}

class PDF extends FPDF
{
    // Page header
    function Header()
    {
        // Logo
        $this->Image('resources/img/logo.jpg', 10, 6, 30);
        // Arial bold 15
        $this->SetFont('Arial', 'B', 15);
        // Move to the right
        $this->Cell(60);
        // Title
        $this->Cell(90, 10, 'Tiket de Venta VaneShop', 1, 0, 'C');
        // Line break
        $this->Ln(20);
    }

    // Page footer
    function Footer()
    {
        // Position at 1.5 cm from bottom
        $this->SetY(-15);
        // Arial italic 8
        $this->SetFont('Arial', 'I', 8);
        // Page number
        $this->Cell(0, 10, 'Page ' . $this->PageNo() . '/{nb}', 0, 0, 'C');
    }
}

// Instanciation of inherited class
$pdf = new PDF();
$pdf->AliasNbPages();
$pdf->AddPage();
$pdf->SetFont('Times', '', 12);

$pdf->Cell(20, 10, "Cantidad", 1, 0, 'C');
$pdf->Cell(90, 10, "Producto", 1, 0, 'C');
$pdf->Cell(30, 10, "Importe", 1, 0, 'C');
$pdf->Cell(30, 10, "Foto", 1, 1, 'C');
while ($item = $car->fetch_assoc()) {
    $pdf->Cell(20, 30, $item['cantida'], 1, 0, 'C');
    $pdf->Cell(90, 30, $item['nombre_prenda'], 1, 0, 'C');
    $pdf->Cell(30, 30, $item['price'], 1, 0, 'C');
    $pdf->Cell(30, 30, $pdf->Image('resources/prendas/'.$item['fk_producto'].".jpg", $pdf->GetX()+5, $pdf->GetY(), 20), 1, 1, 'C');
    
}
$pdf->Cell(110, 10, "Total: $", 1, 0, 'R');
$pdf->Cell(30, 10, $total, 1, 0, 'C');
//$pdf->Output();
$pdf->Output('D', 'Tiket_venta-vaneShop.pdf');
?>
?>